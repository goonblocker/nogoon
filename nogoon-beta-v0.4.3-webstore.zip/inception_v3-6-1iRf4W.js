var r = function() {
  return import("./model.min-DpPqsLBT.js");
}, n = [
  function() {
    return import("./group1-shard1of6.min-B3wLP5sA.js");
  },
  function() {
    return import("./group1-shard2of6.min-CuiKv3tS.js");
  },
  function() {
    return import("./group1-shard3of6.min-DE3q9Q7c.js");
  },
  function() {
    return import("./group1-shard4of6.min-BUNXxkO8.js");
  },
  function() {
    return import("./group1-shard5of6.min-Wwd6aCe7.js");
  },
  function() {
    return import("./group1-shard6of6.min-Dt1R_Mlx.js");
  }
];
export {
  r as modelJson,
  n as weightBundles
};
