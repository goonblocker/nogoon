var r = function() {
  return import("./model.min-CGZ3c5Sx.js");
}, n = [
  function() {
    return import("./group1-shard1of1.min-BRDAbUWo.js");
  }
];
export {
  r as modelJson,
  n as weightBundles
};
