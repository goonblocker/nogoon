var r = function() {
  return import("./model.min-CDcajF2B.js");
}, n = [
  function() {
    return import("./group1-shard1of2.min-DpAb15b9.js");
  },
  function() {
    return import("./group1-shard2of2.min-INtTb8Yi.js");
  }
];
export {
  r as modelJson,
  n as weightBundles
};
